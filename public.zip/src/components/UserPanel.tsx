import { useState, useEffect } from 'react';
import { mockTemplates } from './MockData';
import { exportApplicationToPDF } from '../utils/ExportUtils';
import ApplicationForm from './ApplicationForm';
import CharityBot from './CharityBot';
import { User, Application } from '../types';
import styles from './UserPanel.module.css';

export interface UserPanelProps {
  user: User;
}

export default function UserPanel({ user }: UserPanelProps) {
  const [view, setView] = useState('list'); // 'list' | 'create' | 'view_only' | 'edit'
  const [activeTab, setActiveTab] = useState('ledger'); // 'ledger' | 'reports'
  const [apps, setApps] = useState<Application[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeApp, setActiveApp] = useState<Application | any>(null);
  const [availableTemplates, setAvailableTemplates] = useState<any[]>([]);
  const [isBotEnabled, setIsBotEnabled] = useState(true);

  // Form State
  const [projectName, setProjectName] = useState('');
  const [funderName, setFunderName] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [availableCommonFields, setAvailableCommonFields] = useState([]);
  const [selectedCommonKeys, setSelectedCommonKeys] = useState([]);
  const [appSpecificFields, setAppSpecificFields] = useState([]);
  const [status, setStatus] = useState('DRAFT');
  const [outcomeComments, setOutcomeComments] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  useEffect(() => {
    const fetchApps = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('http://localhost:8080/app/applications', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ charityId: user.charityId || 1 })
        });
        if (!response.ok) throw new Error('API Sync Failed');
        const data = await response.json();
        setApps(data);
      } catch (err) {
        console.warn("API Ledger Sync Failed, restoring High-Fidelity Mock Repository.");
        const fallbackApps = [
          {
            "id": 1001,
            "applicationNumber": "APP-20260128104530",
            "projectName": "Education Support Project",
            "funderName": "ABC Foundation",
            "status": "SUBMITTED",
            "modifiedAt": "2026-01-28T11:30:15"
          },
          {
            "id": 1002,
            "applicationNumber": "APP-20260329113015",
            "projectName": "Healthcare Initiative",
            "funderName": "XYZ Trust",
            "status": "DRAFT",
            "modifiedAt": "2026-03-30T09:15:00"
          },
          {
            "id": 1003,
            "applicationNumber": "APP-20260218113017",
            "projectName": "Random Initiative",
            "funderName": "PQR Trust",
            "status": "FUNDED",
            "modifiedAt": "2026-02-18T09:15:00"
          }
        ];
        // Ensure every fallback has an id
        setApps(fallbackApps as Application[]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchApps();
  }, [user.charityId]);

  useEffect(() => {
    const fetchTemplateFields = async () => {
      if (!selectedTemplateId || isNaN(Number(selectedTemplateId))) {
        setAvailableCommonFields([]);
        if (view === 'create') setSelectedCommonKeys([]);
        return;
      }

      setIsLoading(true);
      try {
        const response = await fetch(`http://localhost:8080/app/common-data/${selectedTemplateId}`);
        if (!response.ok) throw new Error('Schema Fetch Failed');
        const data = await response.json();
        const fields = data.dataJson || [];
        setAvailableCommonFields(fields);
        // By default select all fields for new applications
        if (view === 'create') setSelectedCommonKeys(fields.map((f: any) => f.id));
      } catch (err) {
        console.warn("Template Schema Sync Failed, restoring High-Fidelity Schema Mock.");
        const fallbackSchema: any = {
          "charityId": user.charityId || 101,
          "templateName": "Charity Basic Information",
          "dataJson": [
            { "id": 1, "key": "organizationName", "value": "Helping Hands Trust", "comments": "Official name" },
            { "id": 2, "key": "city", "value": "Hyderabad", "comments": "Head office location" }
          ]
        };
        const fields = fallbackSchema.dataJson || [];
        setAvailableCommonFields(fields);
        if (view === 'create') setSelectedCommonKeys(fields.map((f: any) => f.id));
      } finally {
        setIsLoading(false);
      }
    };

    fetchTemplateFields();
  }, [selectedTemplateId, view]);

  const handleCreateNew = async () => {
    resetForm();
    setActiveApp(null);
    setView('create');

    setIsLoading(true);
    try {
      const response = await fetch(`http://localhost:8080/app/common-data/charity/${user.charityId || 1}`);
      if (!response.ok) throw new Error('Template Directory Sync Failed');
      const data = await response.json();
      setAvailableTemplates(data);
    } catch (err) {
      console.warn("Template Directory Sync Failed, using baseline mock data.");
      setAvailableTemplates(mockTemplates as any);
    } finally {
      setIsLoading(false);
    }
  };

  const loadAppData = async (app: Application | any) => {
    setIsLoading(true);
    try {
      const response = await fetch(`http://localhost:8080/app/applications/${app.id || app.applicationNumber}`);
      if (!response.ok) throw new Error('Detail Fetch Failed');
      const fullApp = await response.json();

      setActiveApp(fullApp);
      setProjectName(fullApp.projectName || "");
      setFunderName(fullApp.funderName || "");
      setSelectedTemplateId(fullApp.templateName ? `${fullApp.templateName} (${fullApp.version || 'v1'})` : "");
      setStatus(fullApp.status || 'DRAFT');
      setOutcomeComments(fullApp.outcome_comments || '');

      // backend provides objects directly
      setAppSpecificFields(fullApp.applicationDataJson || []);
      setAvailableCommonFields(fullApp.dataJson || []);
      // For selected keys, we use everything present in dataJson in view mode
      setSelectedCommonKeys((fullApp.dataJson || []).map((f: any) => f.id));

    } catch (err) {
      console.warn("Detail Sync Failed, restoring High-Fidelity Project Mock.");
      const fallbackDetail: any = {
        "id": 1,
        "applicationNumber": "APP-20260218113017",
        "projectName": "Random Initiative",
        "funderName": "PQR Trust",
        "status": "FUNDED",
        "modifiedAt": "2026-02-18T09:15:00",
        "templateName": "helping project",
        "version": "v2026-03-29",
        "applicationDataJson": [
          { "id": 101, "key": "registrationNumber", "value": "REG-456789", "comments": "Verified from official document" },
          { "id": 102, "key": "fundingAmount", "value": "500000", "comments": "Approved budget" }
        ],
        "dataJson": [
          { "id": 1, "key": "organizationName", "value": "Helping Hands Trust", "comments": "Official name" },
          { "id": 2, "key": "city", "value": "Hyderabad", "comments": "Head office location" }
        ]
      };

      setActiveApp(fallbackDetail);
      setProjectName(fallbackDetail.projectName);
      setFunderName(fallbackDetail.funderName);
      setSelectedTemplateId(`${fallbackDetail.templateName} (${fallbackDetail.version})`);
      setStatus(fallbackDetail.status);
      setOutcomeComments("");
      setAppSpecificFields(fallbackDetail.applicationDataJson);
      setAvailableCommonFields(fallbackDetail.dataJson);
      setSelectedCommonKeys(fallbackDetail.dataJson.map((f: any) => f.id));
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = (app: Application) => { loadAppData(app); setView('edit'); };
  const handleView = (app: Application) => { loadAppData(app); setView('view_only'); };
  const handleExportPDF = (app: Application) => { exportApplicationToPDF(app as any, user); };

  const resetForm = () => {
    setProjectName(''); setFunderName(''); setSelectedTemplateId('');
    setSelectedCommonKeys([]); setAppSpecificFields([]);
    setStatus('DRAFT'); setOutcomeComments('');
    setValidationErrors([]);
  };

  const toggleCommonField = (id: any) => {
    if (selectedCommonKeys.includes(id)) {
      setSelectedCommonKeys(selectedCommonKeys.filter(k => k !== id));
    } else {
      setSelectedCommonKeys([...selectedCommonKeys, id]);
    }
  };

  const saveApplication = async () => {
    // --- Validation Guard ---
    const errors: string[] = [];
    if (!projectName.trim()) errors.push('Project Title');
    if (!funderName.trim()) errors.push('Funder Name');
    if (!selectedTemplateId) errors.push('Linked Template');
    if (availableCommonFields.length > 0 && selectedCommonKeys.length === 0) errors.push('Charity Fields');
    const invalidSpecific = appSpecificFields.some((f: any) => !f.key.trim() || !f.value.trim());
    if (invalidSpecific) errors.push('App Specific Data (key & value required)');

    if (errors.length > 0) {
      setValidationErrors(errors);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setValidationErrors([]);
    const now = new Date();
    const timestamp = now.getFullYear() +
      String(now.getMonth() + 1).padStart(2, '0') +
      String(now.getDate()).padStart(2, '0') +
      String(now.getHours()).padStart(2, '0') +
      String(now.getMinutes()).padStart(2, '0') +
      String(now.getSeconds()).padStart(2, '0');

    const payload: any = {
      applicationNumber: activeApp ? activeApp.applicationNumber : `APP-${timestamp}`,
      projectName: projectName,
      funderName: funderName,
      status: status,
      statusComments: outcomeComments,
      commonDataId: parseInt(selectedTemplateId),
      selectedCommonKeys: JSON.stringify(selectedCommonKeys),
      applicationDataJson: JSON.stringify(
        appSpecificFields
          .filter((f: any) => f.key.trim() !== '')
          .map(({ key, value, comment, comments }: any) => ({ key, value, comments: comment || comments }))
      )
    };

    setIsLoading(true);
    try {
      const response = await fetch('http://localhost:8080/app/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const savedRecord = await response.json();
      const finalData = { ...payload, id: savedRecord.id, modifiedAt: new Date().toISOString() };

      if (activeApp) {
        setApps(apps.map((a: any) => (a.id === activeApp.id || a.applicationNumber === activeApp.applicationNumber) ? finalData : a));
      } else {
        setApps([finalData, ...apps]);
      }
    } catch (err) {
      console.warn("Persistence sync failed, using local optimistic update.");
      const optimisticData = { ...payload, id: activeApp ? activeApp.id : Date.now(), modifiedAt: new Date().toISOString() };
      if (activeApp) {
        setApps(apps.map((a: any) => (a.id === activeApp.id || a.applicationNumber === activeApp.applicationNumber) ? optimisticData : a));
      } else {
        setApps([optimisticData, ...apps]);
      }
    } finally {
      setIsLoading(false);
      resetForm();
      setView('list');
    }
  };

  return (
    <div className={`animate-fade-in ${styles.root}`}>

      {/* --- FORM VIEW --- */}
      {(view === 'create' || view === 'edit' || view === 'view_only') && (
        <div className={styles.formWrapper}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className={styles.pageTitle}>
                {view === 'create' ? 'Create Application' : view === 'edit' ? 'Edit Application Record' : 'Application Summary'}
              </h2>
              <p className={styles.pageSubtitle}>Organization: {user.charityName}</p>
            </div>
          </div>

          <ApplicationForm
            view={view} user={user}
            projectName={projectName} setProjectName={setProjectName}
            funderName={funderName} setFunderName={setFunderName}
            status={status} setStatus={setStatus}
            outcomeComments={outcomeComments} setOutcomeComments={setOutcomeComments}
            selectedTemplateId={selectedTemplateId} setSelectedTemplateId={setSelectedTemplateId}
            availableTemplates={availableTemplates}
            availableCommonFields={availableCommonFields}
            selectedCommonKeys={selectedCommonKeys} toggleCommonField={toggleCommonField}
            appSpecificFields={appSpecificFields} setAppSpecificFields={setAppSpecificFields}
            saveApplication={saveApplication}
            handleExportPDF={handleExportPDF}
            activeApp={activeApp}
            validationErrors={validationErrors}
          />

          <div className={styles.formActions}>
            <button className={`btn btn-outline ${styles.btnReturn}`} onClick={() => { setView('list'); resetForm(); }}>Return to Ledger</button>
            {view !== 'view_only' && <button className={`btn btn-primary ${styles.btnSave}`} onClick={saveApplication}>{activeApp ? 'Update Application' : 'Finalize & Submit'}</button>}
            {view === 'view_only' && <button className={`btn btn-primary ${styles.btnPdf}`} onClick={() => handleExportPDF(activeApp)}>Generate PDF Copy</button>}
          </div>

          <CharityBot isEnabled={isBotEnabled} />
        </div>
      )}

      {/* --- LIST VIEW --- */}
      {view === 'list' && (
        <>
          <div className="flex justify-between items-center mb-10">
            <div>
              <h2 className={styles.ledgerTitle}>Application Ledger</h2>
              <p className={styles.pageSubtitle}>HISTORY OVERVIEW FOR: {user.charityName}</p>
            </div>
            <div className="flex gap-4 items-center">
              <div className={styles.voiceAssistantBadge}>
                <span className={styles.voiceAssistantLabel}>VOICE ASSISTANT</span>
                <input type="checkbox" checked={isBotEnabled} onChange={e => setIsBotEnabled(e.target.checked)} className={styles.voiceAssistantCheckbox} />
              </div>
              <button className="btn btn-primary" onClick={handleCreateNew}>+ New Project Application</button>
            </div>
          </div>

          <div className={`card ${styles.tableCard}`}>
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className={styles.tableHeader}>Submissions Directory</h3>
              <input type="text" className={`form-control ${styles.searchInput}`} placeholder="🔍 Filter Project or Funder..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>

            <div className="table-container">
              <table>
                <thead>
                  <tr style={{ background: '#e6f1ef' }}>
                    <th className={styles.th}>REF #</th>
                    <th className={styles.th}>PROJECT</th>
                    <th className={styles.th}>FUNDER</th>
                    <th className={styles.th}>MODIFIED DATE</th>
                    <th className={styles.th}>STATUS</th>
                    <th className={styles.th}>ACTIONS</th>
                  </tr>
                </thead>
                <tbody>
                  {apps.filter(a => (a.projectName || "").toLowerCase().includes(searchTerm.toLowerCase()) || (a.funderName || "").toLowerCase().includes(searchTerm.toLowerCase())).length === 0 ? (
                    <tr><td colSpan={6} className={`text-center ${styles.tdEmpty}`}>{isLoading ? 'Synchronizing with Ledger...' : 'No application history available.'}</td></tr>
                  ) : (
                    apps.filter(a => (a.projectName || "").toLowerCase().includes(searchTerm.toLowerCase()) || (a.funderName || "").toLowerCase().includes(searchTerm.toLowerCase())).map(a => (
                      <tr key={(a as any).id || a.applicationNumber}>
                        <td><strong style={{ color: 'var(--primary)', fontSize: '0.9rem' }}>{a.applicationNumber}</strong></td>
                        <td className={styles.tdProject}>{a.projectName}</td>
                        <td className={styles.tdFunder}>{a.funderName}</td>
                        <td className={styles.tdDate}>
                          {a.modifiedAt ? new Date(a.modifiedAt).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                        </td>
                        <td>
                          <span className={`badge ${a.status === 'DRAFT' ? 'badge-gray' : a.status === 'REJECTED' ? 'badge-danger' : a.status === 'FUNDED' ? 'badge-success' : 'badge-green'}`}>{a.status}</span>
                        </td>
                        <td>
                          <div className="flex gap-4">
                            <button onClick={() => handleView(a)} title="Full Overview"><svg width="18" height="18" fill="none" stroke="#64748b" strokeWidth="2" viewBox="0 0 24 24"><path d="M11 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg></button>
                            <button onClick={() => handleEdit(a)} title="Update Content & Status"><svg width="18" height="18" fill="none" stroke="#006a4d" strokeWidth="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" /></svg></button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
