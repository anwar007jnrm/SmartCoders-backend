import { useState, useEffect, useRef } from 'react';
import CharityBot from './CharityBot';
import styles from './AdminPanel.module.css';

// DB Mock Structure
const initialTemplates = [
  {
    id: 1,
    charity_id: 1,
    version: '2023-10-12',
    title: 'Financial Disclosure',
    description: 'Standardized reporting for annual revenue and overhead allocation.',
    dataJson: [
      { id: 101, key: 'tax_id', value: '12-3456789', comment: 'LBG Internal Reference' },
      { id: 102, key: 'annual_revenue', value: '5000000', comment: 'Audited 2024' }
    ],
    created_at: '2023-10-12T10:00:00Z',
    is_active: true
  },
  {
    id: 2,
    charity_id: 1,
    version: '2023-11-05',
    title: 'Impact Assessment',
    description: 'Quantitative metrics for community-level intervention results.',
    dataJson: [
      { id: 201, key: 'beneficiary_count', value: '15000', comment: 'Q4 Impact' },
      { id: 202, key: 'region_served', value: 'Global South', comment: 'Strategy Alignment' }
    ],
    created_at: '2023-11-05T10:00:00Z',
    is_active: true
  }
];

import { User, Template, TemplateField } from '../types';

interface AdminPanelProps {
  user: User;
}

export default function AdminPanel({ user }: AdminPanelProps) {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  const [editFields, setEditFields] = useState<TemplateField[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isBotEnabled, setIsBotEnabled] = useState(true);
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' }>({ key: 'date', direction: 'desc' });

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchTemplates = async () => {
      setIsLoading(true);
      console.log(`[Admin] Synchronizing Schema Directory for Charity ${user.charityId || 101}...`);

      try {
        const charityId = user.charityId || 101;
        const response = await fetch(`http://localhost:8080/api/charity/${charityId}`);
        if (!response.ok) throw new Error('Backend unreachable');
        const data = await response.json();
        setTemplates(data);
      } catch (err) {
        console.warn("[Admin] API Fetch failed, restoring High-Fidelity Mock Directory.");
        setTemplates(initialTemplates as any);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTemplates();
  }, [user.charityId]);

  const handleEdit = (tmpl: Template) => {
    setEditingTemplate(tmpl);
    // Directly use the array coming from the backend / mock
    setEditFields(tmpl.dataJson || []);
  };

  const handleCreateNew = () => {
    const freshTemplate: Template = {
      id: Date.now(),
      charity_id: user.charityId,
      version: "0",
      title: 'New Schema Template',
      description: 'Describe the purpose of these common data fields...',
      created_at: new Date().toISOString(),
      is_active: true,
      data_json: ''
    };
    setEditingTemplate(freshTemplate);
    setEditFields([]);
  };

  const addField = () => {
    setEditFields([...editFields, { id: Date.now() + Math.random(), key: '', value: '', comment: '' }]);
  };

  const updateField = (index: number, fieldName: keyof TemplateField, newVal: string) => {
    const updated = [...editFields];
    (updated[index] as any)[fieldName] = newVal;
    setEditFields(updated);
  };

  const removeField = (index: number) => {
    const updated = editFields.filter((_, i) => i !== index);
    setEditFields(updated);
  };

  const saveAsNewVersion = async () => {
    if (!editingTemplate) return;
    const filteredFields = editFields.filter(f => f.key.trim() !== '' || f.value.trim() !== '');

    // Now send the array directly as requested, not a stringified version
    const dataJson = filteredFields.map(f => ({
      key: f.key,
      value: f.value,
      comments: f.comment || ""
    }));

    const nextVersion = new Date().toISOString().split('.')[0];
    
    const apiPayload = {
      templateName: editingTemplate.templateTitle || editingTemplate.title || "New Template",
      description: editingTemplate.description || "",
      charityId: user.charityId,
      dataJson: dataJson, // Object array directly
      version: nextVersion
    };

    try {
      const response = await fetch('http://localhost:8080/app/common-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(apiPayload)
      });
      if (!response.ok) throw new Error('API failed');
      console.log("Template saved successfully to backend.");
    } catch (err) {
      console.warn("API save failed, persisting locally for now.");
    }

    // Local state update to ensure UI is snappy
    const newTmpl: Template = {
      ...editingTemplate,
      id: Date.now(),
      charity_id: user.charityId,
      version: nextVersion,
      dataJson: filteredFields,
      created_at: new Date().toISOString()
    };

    setTemplates([newTmpl, ...templates]);
    setEditingTemplate(null);
    setEditFields([]);
  };

  // Filter templates based on search term
  const filteredTemplates = templates.filter(t => {
    const title = t.templateTitle || t.title || '';
    const desc = t.description || '';
    return title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      desc.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Sort logic
  const sortedTemplates = [...filteredTemplates].sort((a, b) => {
    let aVal: string | number = '';
    let bVal: string | number = '';

    if (sortConfig.key === 'title') {
      aVal = (a.templateTitle || a.title || '').toLowerCase();
      bVal = (b.templateTitle || b.title || '').toLowerCase();
    } else if (sortConfig.key === 'version') {
      aVal = a.version || '';
      bVal = b.version || '';
    } else if (sortConfig.key === 'date') {
      aVal = new Date(a.createdAt || a.created_at || 0).getTime();
      bVal = new Date(b.createdAt || b.created_at || 0).getTime();
    }

    if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const requestSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: string) => {
    if (sortConfig.key !== key) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  if (editingTemplate) {
    return (
      <div className={`animate-fade-in ${styles.root}`}>
        <div style={{ marginBottom: '2rem' }}>
          <h2 className={styles.pageTitle}>Edit Charity Data Template</h2>
          <p className={styles.pageSubtitle}>
            Original Version: v{editingTemplate.version} | Charity: {user.charityName || editingTemplate.charity_id}
          </p>
        </div>

        <div className={`card mb-4 ${styles.editCard}`}>
          <div className={styles.editMetaRow}>
            <div className={`form-group mb-0 ${styles.editMetaField}`}>
              <label className={`form-label ${styles.editMetaLabel}`}>Template Title</label>
              <input type="text" className="form-control" value={editingTemplate.title}
                onChange={e => setEditingTemplate({ ...editingTemplate, title: e.target.value })} />
            </div>
            <div className={`form-group mb-0 ${styles.editMetaField}`}>
              <label className={`form-label ${styles.editMetaLabel}`}>Description</label>
              <input type="text" className="form-control" value={editingTemplate.description}
                onChange={e => setEditingTemplate({ ...editingTemplate, description: e.target.value })} />
            </div>
          </div>

          <h3 className={styles.sectionTitle}>Schema Fields</h3>
          <p className={styles.sectionHint}>Configure the required key-value pairs inline using text areas.</p>

          <div className={styles.schemaFieldsList}>
            {editFields.length === 0 && (
              <div className={styles.schemaEmptyState}>
                <p className={styles.schemaEmptyText}>No schema fields defined yet.</p>
                <button className="btn btn-primary" onClick={addField}>+ Start Adding Schema Fields</button>
              </div>
            )}
            {editFields.map((f, i) => (
              <div key={f.id} className={`flex gap-4 items-stretch ${styles.schemaFieldRow}`}>
                <textarea className={`form-control ${styles.textareaKey}`} placeholder="Key (e.g. tax_id)"
                  value={f.key} onChange={e => updateField(i, 'key', e.target.value)} />
                <textarea className={`form-control ${styles.textareaValue}`} placeholder="Value / Default Text"
                  value={f.value} onChange={e => updateField(i, 'value', e.target.value)} />
                <textarea className={`form-control ${styles.textareaComment}`} placeholder="Notes..."
                  value={f.comment || ''} onChange={e => updateField(i, 'comment', e.target.value)} />

                <div className={styles.schemaActionCol}>
                  {i === editFields.length - 1 && (
                    <>
                      <button className={styles.btnAdd} onClick={addField} title="Add Field">+</button>
                      <button className={styles.btnRemove} onClick={() => removeField(i)} title="Delete Field">−</button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className={styles.editActions}>
          <button className={`btn btn-outline ${styles.btnDiscard}`} onClick={() => setEditingTemplate(null)}>Discard Changes</button>
          <button className={`btn btn-primary ${styles.btnSaveTemplate}`} onClick={saveAsNewVersion}>Save as New Template</button>
        </div>

        <CharityBot isEnabled={isBotEnabled} />
      </div>
    );
  }

  // ---- RENDER LIST VIEW ---- //
  return (
    <div className={`animate-fade-in ${styles.root}`}>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className={styles.pageTitle}>Charity Data Templates</h2>
          <p className={styles.pageSubtitle}>
            MANAGE STRUCTURAL APPLICATION SCHEMAS FOR: {user.charityName?.toUpperCase() || `CHARITY #${user.charityId}`}
          </p>
        </div>
        <div className="flex gap-4 items-center">
          <div className={styles.voiceAssistantBadge}>
            <span className={styles.voiceAssistantLabel}>VOICE ASSISTANT</span>
            <input type="checkbox" checked={isBotEnabled} onChange={e => setIsBotEnabled(e.target.checked)} className={styles.voiceAssistantCheckbox} />
          </div>
          <button className="btn btn-primary" onClick={handleCreateNew}>+ Create New Template</button>
        </div>
      </div>

      <div className="card" style={{ padding: '0', border: 'none', background: 'transparent' }}>
        <div className="flex justify-between items-center mb-4">
          <h3 className={styles.sectionTitle} style={{ marginTop: 0, marginBottom: 0 }}>Template Directory</h3>
          <input type="text" className="form-control" style={{ width: '300px', backgroundColor: '#fff' }}
            placeholder="🔍 Search templates by title or description..."
            value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>

        <div className={`table-container ${styles.tableContainer}`}>
          <table>
            <thead>
              <tr className={styles.theadRow}>
                <th className={styles.thSortable} style={{ width: '30%' }} onClick={() => requestSort('title')}>
                  Template Title <span className={styles.thSortIcon}>{getSortIcon('title')}</span>
                </th>
                <th className={styles.th} style={{ width: '30%' }}>Description</th>
                <th className={styles.thSortable} style={{ width: '10%' }} onClick={() => requestSort('version')}>
                  Version <span className={styles.thSortIcon}>{getSortIcon('version')}</span>
                </th>
                <th className={styles.thSortable} style={{ width: '15%' }} onClick={() => requestSort('date')}>
                  Created Date <span className={styles.thSortIcon}>{getSortIcon('date')}</span>
                </th>
                <th className={styles.th} style={{ width: '15%' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedTemplates.length === 0 ? (
                <tr><td colSpan={5} className={`text-center ${styles.tdEmpty}`}>No templates found matching your search.</td></tr>
              ) : (
                sortedTemplates.map(t => {
                  const displayTitle = t.templateTitle || t.title || 'Untitled Template';
                  const dateStr = t.createdAt || t.created_at || '';
                  const formattedDate = dateStr ? new Date(dateStr).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : 'N/A';
                  return (
                    <tr key={t.id}>
                      <td>
                        <div className="flex items-center gap-3">
                          <div className={styles.templateIconWrap}>
                            <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" /></svg>
                          </div>
                          <strong style={{ color: 'var(--primary)', fontSize: '0.95rem' }}>{displayTitle}</strong>
                        </div>
                      </td>
                      <td className={styles.tdDescription}>{t.description}</td>
                      <td><span className="badge badge-blue">v{t.version || '1'}</span></td>
                      <td className={styles.tdDate}>{formattedDate}</td>
                      <td>
                        <button className={`btn btn-outline ${styles.btnViewEdit}`} onClick={() => handleEdit(t)}>View / Edit</button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
