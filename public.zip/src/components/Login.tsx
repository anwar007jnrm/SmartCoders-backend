import { useState, useEffect } from 'react';
import styles from './Login.module.css';
import { User } from '../types';

interface Charity {
  id: number;
  name: string;
}

interface LoginProps {
  onLogin: (user: User) => void;
}

// Mock Charity API response
const mockCharityAPI: Charity[] = [
  { id: 1, name: 'Helping Hands Trust' },
  { id: 2, name: 'Green Foundation' },
  { id: 3, name: 'Save the Children UK' },
  { id: 4, name: 'Cancer Research UK' },
  { id: 5, name: 'The British Red Cross' },
  { id: 6, name: 'Global System (Internal)' }
];

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedCharityId, setSelectedCharityId] = useState('');
  const [availableCharities, setAvailableCharities] = useState<Charity[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCharityDirectory = async () => {
      console.log('[Portal Auth] Initializing Directory: Fetching /api/charity...');
      
      try {
        const response = await fetch('/api/charity');
        if (response.ok) {
          const data = await response.json();
          setAvailableCharities(data);
          console.log('[Portal Auth] Directory populated via Real Backend API.');
        } else {
          throw new Error('Backend responded with error code');
        }
      } catch (err) {
        console.warn('[Portal Auth] Backend Charity API unreachable. Restoring Mock Directory for development.');
        setAvailableCharities(mockCharityAPI);
      }
    };

    fetchCharityDirectory();
  }, []);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    const loginPayload = {
      username: username.toLowerCase(),
      password: password,
      charityId: parseInt(selectedCharityId)
    };

    console.log('[Portal Auth] Attempting secure login with payload:', loginPayload);

    try {
      // 1. Attempt Real Backend Call
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginPayload)
      });

      if (response.ok) {
        const userData = await response.json();
        onLogin(userData);
        return;
      }
      
      const errorData = await response.json();
      setError(errorData.message || 'Authentication failed via Backend API.');

    } catch (err) {
      // 2. FALLBACK: API IS DOWN - USE MOCK LOGIC
      console.warn('[Portal Auth] Backend API unreachable. Falling back to local Mock Directory.');
      
      const mockUsers: import('../types').User[] = [
        { id: 99, username: 'super', role: 'SUPERUSER' as const, charityId: 6, charityName: 'Global System (Internal)' },
        { id: 1, username: 'admin', role: 'ADMIN' as const, charityId: 1, charityName: 'Helping Hands Trust' },
        { id: 2, username: 'user1', role: 'USER' as const, charityId: 1, charityName: 'Helping Hands Trust' },
        { id: 3, username: 'green_admin', role: 'ADMIN' as const, charityId: 2, charityName: 'Green Foundation' },
        { id: 4, username: 'redcross_user', role: 'USER' as const, charityId: 5, charityName: 'The British Red Cross' }
      ];

      const foundUser = mockUsers.find(u => u.username === loginPayload.username);

      if (!foundUser) {
        setError('Invalid username or password (Mock Directory)');
        return;
      }

      if (foundUser.charityId !== loginPayload.charityId) {
        const intendedCharity = availableCharities.find(c => c.id === foundUser.charityId);
        setError(`Access Denied: Your account is restricted to "${intendedCharity?.name}". You cannot log in via the selected charity.`);
        return;
      }

      onLogin(foundUser);
    }
  };

  return (
    <div className={`flex-center ${styles.pageRoot}`}>
      <div className={`glass-panel ${styles.panel}`}>
        <div className={styles.logoWrap}>
          <div className={styles.logoIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
          </div>
          <h2 className={styles.logoTitle}>CharityConnect Portal</h2>
          <p className={styles.logoSubtitle}>Secured by Lloyds Banking Group Identity</p>
        </div>

        {error && <div className={`alert alert-error animate-fade-in ${styles.errorAlert}`}>{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">AFFILIATED CHARITY</label>
            <select className={`form-control ${styles.charitySelect}`}
              value={selectedCharityId} onChange={e => setSelectedCharityId(e.target.value)} required>
              <option value="">-- Choose your Organization --</option>
              {availableCharities.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">USERNAME</label>
            <input type="text" className="form-control" value={username}
              onChange={(e) => setUsername(e.target.value)} placeholder="e.g. admin_hq" required />
          </div>

          <div className="form-group mb-6">
            <label className="form-label">PASSWORD</label>
            <input type="password" className="form-control" value={password}
              onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
          </div>

          <button type="submit" className={`btn btn-primary ${styles.btnSubmit}`}>Portal Sign In</button>
        </form>

        <div className={styles.credHint}>
          <p className={styles.credHintTitle}>Active Directory Map:</p>
          <div className={styles.credGrid}>
            <div>User: <b>user1</b> (Charity 1)</div>
            <div>User: <b>admin</b> (Charity 1)</div>
            <div>User: <b>super</b> (System Internal)</div>
            <div>User: <b>green_admin</b> (Charity 2)</div>
          </div>
        </div>
      </div>
    </div>
  );
}
