import { useState, useEffect } from 'react';
import { User, Application } from '../types';
import { exportApplicationToPDF } from '../utils/ExportUtils';
import styles from './UserPanel.module.css'; // Reuse table and search styles

interface ApplicationReportsProps {
  user: User;
  onPrint: (app: any) => void;
}

export default function ApplicationReports({ user, onPrint }: ApplicationReportsProps) {
  const [apps, setApps] = useState<Application[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedApp, setSelectedApp] = useState<Application | any>(null);
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  useEffect(() => {
    const fetchApps = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('http://localhost:8080/app/applications', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ charityId: user.charityId || 1 })
        });
        const data = await response.json();
        setApps(data);
      } catch (err) {
        console.warn("Using sample data for reports");
        setApps([
          { "id": 1001, "applicationNumber": "APP-20260128104530", "projectName": "Education Support Project", "funderName": "ABC Foundation", "status": "SUBMITTED", "modifiedAt": "2026-01-28T11:30:15" },
          { "id": 1002, "applicationNumber": "APP-20260329113015", "projectName": "Healthcare Initiative", "funderName": "XYZ Trust", "status": "DRAFT", "modifiedAt": "2026-03-30T09:15:00" }
        ]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchApps();
  }, [user.charityId]);

  const handleSelectApp = async (app: Application) => {
    setIsLoading(true);
    try {
      const response = await fetch(`http://localhost:8080/app/applications/${app.id || app.applicationNumber}`);
      const fullApp = await response.json();
      setSelectedApp(fullApp);
    } catch (err) {
      setSelectedApp({
        ...app,
        applicationDataJson: [
          { id: 1, key: "Registration Number", value: "REG-12345", comment: "Verified" },
          { id: 2, key: "Budget Required", value: "£50,000", comment: "Itemized" }
        ],
        dataJson: [
          { id: 101, key: "Charity Name", value: user.charityName || "Helping Hands", comment: "Official" }
        ]
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopySuccess(label);
    setTimeout(() => setCopySuccess(null), 2000);
  };

  const filteredApps = apps.filter(a => 
    a.projectName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    a.funderName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.applicationNumber?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="animate-fade-in" style={{ paddingBottom: '3rem' }}>
      <div className="mb-8">
        <h2 style={{ fontSize: '1.75rem', fontWeight: 700, margin: 0, color: 'var(--primary)' }}>Application Search & Reports</h2>
        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginTop: '0.25rem', fontWeight: 600 }}>
          Search for applications, copy data fields, and generate PDF copies
        </p>
      </div>

      <div className="grid-2" style={{ gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1.5fr)', gap: '2rem', alignItems: 'start' }}>
        {/* Left Col: Search & List */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '1.25rem', borderBottom: '1px solid #e2e8f0' }}>
            <input 
              type="text" 
              className="form-control" 
              placeholder="🔍 Search Project, Funder or Ref..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
            {filteredApps.map(a => (
              <div 
                key={a.id || a.applicationNumber} 
                className={`flex justify-between items-center`}
                style={{ 
                  padding: '1rem 1.25rem', 
                  borderBottom: '1px solid #f1f5f9', 
                  cursor: 'pointer',
                  backgroundColor: selectedApp?.applicationNumber === a.applicationNumber ? '#e6f1ef' : 'transparent',
                  transition: 'background-color 0.2s'
                }}
                onClick={() => handleSelectApp(a)}
              >
                <div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)' }}>{a.applicationNumber}</div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 600, color: '#334155' }}>{a.projectName}</div>
                  <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{a.funderName}</div>
                </div>
                <div className={`badge ${a.status === 'FUNDED' ? 'badge-success' : 'badge-gray'}`} style={{ fontSize: '0.65rem' }}>{a.status}</div>
              </div>
            ))}
            {filteredApps.length === 0 && (
              <div style={{ padding: '2rem', textAlign: 'center', color: '#64748b', fontSize: '0.9rem' }}>No applications found.</div>
            )}
          </div>
        </div>

        {/* Right Col: Details & Actions */}
        <div className="card">
          {!selectedApp ? (
            <div style={{ padding: '4rem 2rem', textAlign: 'center', color: '#64748b' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem', opacity: 0.3 }}>📄</div>
              <p>Select an application from the list to view details and generate a PDF copy.</p>
            </div>
          ) : (
            <div>
              <div className="flex justify-between items-start mb-6 pb-6 border-b">
                <div>
                  <h3 style={{ margin: 0, fontWeight: 800, color: 'var(--primary)' }}>{selectedApp.projectName}</h3>
                  <p style={{ margin: '0.25rem 0', fontSize: '0.85rem', color: '#64748b' }}>Ref: {selectedApp.applicationNumber} | Funder: {selectedApp.funderName}</p>
                </div>
                <button 
                  className="btn btn-primary" 
                  onClick={() => onPrint(selectedApp)}
                  style={{ gap: '0.5rem', display: 'flex', alignItems: 'center' }}
                >
                  <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                  Generate PDF Copy
                </button>
              </div>

              {copySuccess && (
                <div role="alert" style={{ 
                  position: 'fixed', bottom: '2rem', right: '2rem', background: '#006a4d', 
                  color: 'white', padding: '0.75rem 1.5rem', borderRadius: '8px', zIndex: 1000, 
                  boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', animation: 'slideIn 0.3s ease-out' 
                }}>
                  Copied "{copySuccess}" to clipboard!
                </div>
              )}

              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <Section title="Charity Profile Data" icon="🏛️">
                  {(selectedApp.dataJson || []).map((f: any) => (
                    <CopyField key={f.id} label={f.key} value={f.value} onCopy={() => handleCopy(f.value, f.key)} />
                  ))}
                  {(!selectedApp.dataJson || selectedApp.dataJson.length === 0) && <p style={{ fontSize: '0.8rem', color: '#94a3b8', fontStyle: 'italic' }}>No profile data linked.</p>}
                </Section>

                <Section title="Application Specific Data" icon="📝">
                  {(selectedApp.applicationDataJson || []).map((f: any) => (
                    <CopyField key={f.id} label={f.key} value={f.value} onCopy={() => handleCopy(f.value, f.key)} />
                  ))}
                  {(!selectedApp.applicationDataJson || selectedApp.applicationDataJson.length === 0) && <p style={{ fontSize: '0.8rem', color: '#94a3b8', fontStyle: 'italic' }}>No specific data fields.</p>}
                </Section>

                {selectedApp.outcome_comments && (
                  <Section title="Reviewer Comments" icon="💬">
                    <div style={{ 
                      padding: '1rem', background: '#f8fafc', borderRadius: '8px', 
                      fontSize: '0.9rem', color: '#334155', borderLeft: '4px solid #cbd5e1' 
                    }}>
                      {selectedApp.outcome_comments}
                    </div>
                  </Section>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Section({ title, icon, children }: any) {
  return (
    <div>
      <h4 style={{ fontSize: '0.8rem', fontWeight: 800, color: '#64748b', textTransform: 'uppercase', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <span>{icon}</span> {title}
      </h4>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {children}
      </div>
    </div>
  );
}

function CopyField({ label, value, onCopy }: any) {
  return (
    <div style={{ 
      background: '#fff', border: '1px solid #e2e8f0', borderRadius: '10px', 
      padding: '0.75rem 1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      transition: 'all 0.2s ease',
      boxShadow: '0 1px 2px rgba(0,0,0,0.02)'
    }} className="copy-field-row">
      <div style={{ flex: 1, marginRight: '1rem' }}>
        <div style={{ fontSize: '0.7rem', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.025em' }}>{label}</div>
        <div style={{ fontSize: '0.95rem', color: '#1e293b', fontWeight: 500, wordBreak: 'break-word', marginTop: '2px' }}>{value}</div>
      </div>
      <button 
        className="btn-icon-only" 
        onClick={onCopy}
        title={`Copy ${label}`}
        style={{ 
          background: '#f8fafc',
          border: '1px solid #e2e8f0',
          borderRadius: '8px',
          padding: '8px',
          cursor: 'pointer',
          color: 'var(--primary)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.2s'
        }}
      >
        <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
    </div>
  );
}
