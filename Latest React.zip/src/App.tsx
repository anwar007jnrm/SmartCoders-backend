import { useState, useEffect } from 'react';
import Login from './components/Login';
import AdminPanel from './components/AdminPanel';
import UserPanel from './components/UserPanel';
import SuperadminPanel from './components/SuperadminPanel';
import Analytics from './components/Analytics';
import ApplicationReports from './components/ApplicationReports';
import RegisterMember from './components/RegisterMember';
import OfficialReport from './components/OfficialReport';
import { User } from './types';

// Basic SVG Icons mapping
const icons = {
  superuser: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" /></svg>,
  config: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" /></svg>,
  templates: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>,
  applications: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>,
  reports: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" /></svg>,
  register: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M18 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0zM3 19.235v-.11a6.375 6.375 0 0 1 12.75 0v.109A12.318 12.318 0 0 1 9.374 21c-2.331 0-4.512-.645-6.374-1.766z" /></svg>,
  logout: <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5 21h-6a2.25 2.25 0 0 1-2.25-2.25V15m-3 0-3-3m0 0 3-3m-3 3H15" /></svg>
};


function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeRoute, setActiveRoute] = useState('applications');
  const [printApp, setPrintApp] = useState<any>(null);

  useEffect(() => {
    // --- Print Interceptor ---
    // If we're in print mode, trigger standard browser print
    if (printApp) {
      setTimeout(() => {
        const element = document.getElementById('printable-area');
        if (element && (window as any).html2pdf) {
          const opt = {
            margin: 0,
            filename: `${printApp.applicationNumber || 'charity_report'}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
          };
          (window as any).html2pdf().set(opt).from(element).save().then(() => {
            setPrintApp(null);
          });
        } else {
          window.print();
          setPrintApp(null);
        }
      }, 500);
    }
  }, [printApp]);

  useEffect(() => {
    // --- Global Clipboard Interceptor ---
    // Allows PDF links to trigger copy actions via URL parameters
    const params = new URLSearchParams(window.location.search);
    const copyText = params.get('copy');
    if (copyText) {
      navigator.clipboard.writeText(decodeURIComponent(copyText)).then(() => {
        // Try to close window if it's the only command
        setTimeout(() => {
          if (window.opener) window.close();
          else window.history.replaceState({}, document.title, "/");
        }, 300);
      });
    }

    const savedUser = localStorage.getItem('charity_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);



  const handleLogin = (loggedInUser: User) => {
    // Global persistence of user identity including charityId
    localStorage.setItem('charity_user', JSON.stringify(loggedInUser));
    setUser(loggedInUser);

    // fetchApplications is now called on-demand via the route watcher useEffect

    // Auto map default routes based on role
    if (loggedInUser.role === 'SUPERUSER') setActiveRoute('superuser');
    if (loggedInUser.role === 'ADMIN') setActiveRoute('templates');
    if (loggedInUser.role === 'USER') setActiveRoute('applications');
  };

  const handleLogout = () => {
    localStorage.removeItem('charity_user');
    setUser(null);
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="app-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-brand">
          <h2>GrantFlow Portal</h2>
          <p>Manage. Apply. Track.</p>
        </div>

        <nav className="sidebar-nav">
          {user.role === 'ADMIN' && (
            <div className={`nav-item ${activeRoute === 'register' ? 'active' : ''}`} onClick={() => setActiveRoute('register')}>
              {icons.register} Member Registration
            </div>
          )}

          {user.role === 'SUPERUSER' && (
            <div className={`nav-item ${activeRoute === 'superuser' ? 'active' : ''}`} onClick={() => setActiveRoute('superuser')}>
              {icons.superuser} Superuser Hub
            </div>
          )}

          {(user.role === 'SUPERUSER' || user.role === 'ADMIN') && (
            <div className={`nav-item ${activeRoute === 'templates' ? 'active' : ''}`} onClick={() => setActiveRoute('templates')}>
              {icons.templates} Charity Data Templates
            </div>
          )}

          <div className={`nav-item ${activeRoute === 'applications' ? 'active' : ''}`} onClick={() => setActiveRoute('applications')}>
            {icons.applications} Applications
          </div>

          <div className={`nav-item ${activeRoute === 'reports' ? 'active' : ''}`} onClick={() => setActiveRoute('reports')}>
            <svg fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width="18" height="18"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>
            Application Reports
          </div>

          <div className={`nav-item ${activeRoute === 'insights' ? 'active' : ''}`} onClick={() => setActiveRoute('insights')}>
            {icons.reports} Analytics & Insights
          </div>
        </nav>

        <div className="sidebar-bottom">
          <div className="nav-item" onClick={handleLogout} style={{ padding: 0 }}>
            {icons.logout} Logout ({user.username})
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <header className="topbar">
          <div className="topbar-brand">
            {/* Brand or title goes here */}
          </div>
          <div className="topbar-right">
            <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span role="img" aria-label="user">👤</span>
            </div>
          </div>
        </header>

        <div className="content-area">
          {activeRoute === 'superuser' && <SuperadminPanel />}
          {activeRoute === 'register' && <RegisterMember user={user} />}
          {activeRoute === 'templates' && <AdminPanel user={user} />}
          {activeRoute === 'applications' && <UserPanel user={user} onPrint={(app: any) => setPrintApp(app)} />}
          {activeRoute === 'reports' && <ApplicationReports user={user} onPrint={(app: any) => setPrintApp(app)} />}
          {activeRoute === 'insights' && <Analytics user={user} />}
        </div>
      </main>

      {/* HIDDEN PRINT CONTAINER */}
      {printApp && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: '#fff', zIndex: 999999 }}>
          <OfficialReport app={printApp} user={user!} />
        </div>
      )}
    </div>
  );
}

export default App;
