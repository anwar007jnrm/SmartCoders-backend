import jsPDF from 'jspdf';
import { mockTemplates } from '../components/MockData';

// Lloyds Banking Group Colors
const LBG_PRIMARY = '#006a4d';
const LBG_DARK = '#004c38';
const LBG_LIGHT_GREEN = '#e6f1ef';
const TEXT_DARK = '#1a1a1a';
const TEXT_MUTED = '#4b5563';

// Safe text helper to prevent rendering crashes with non-standard characters (like emojis)
const safeStr = (str) => {
  if (!str) return "";
  // Strip all characters with code points above 255 (standard Latin-1 range for jsPDF default fonts)
  return String(str).replace(/[^\x00-\xFF]/g, "");
};

export const exportApplicationToPDF = (app, user) => {
  try {
    const doc = new jsPDF();
    const margin = 20;
    const pageWidth = doc.internal.pageSize.width;
    let y = 30;

    console.log('[PDF Export] Starting generation for app:', app.applicationNumber || app.application_number);

  // --- BRAND HEADER ---
  // Large background bar for Header
  doc.setFillColor(LBG_PRIMARY);
  doc.rect(0, 0, pageWidth, 45, 'F');
  
  doc.setFontSize(24);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text(safeStr('GRANT APPLICATION'), margin, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(safeStr(`REF #: ${app.applicationNumber || app.application_number}  |  STATUS: ${(app.status || 'DRAFT').toUpperCase()}`), margin, 35);
  
  y = 60; // Start content below header

  // --- 1. PROJECT & FUNDER SECTION ---
  drawSectionHeader(doc, safeStr('1. PROJECT & FUNDER OVERVIEW'), margin, y);
  y += 12;

  doc.setFontSize(11);
  doc.setTextColor(TEXT_DARK);
  doc.setFont('helvetica', 'bold');
  doc.text(safeStr('PROJECT TITLE:'), margin + 5, y);
  doc.setFont('helvetica', 'normal');
  doc.text(safeStr(String(app.projectName || app.project_name || "N/A")), margin + 50, y);
  doc.setTextColor(LBG_PRIMARY);
  doc.setFontSize(8);
  const projCopyUrl = `http://localhost:5174/?copy=${encodeURIComponent(app.projectName || app.project_name || "")}`;
  doc.text(safeStr('(COPY)'), margin + 180, y);
  doc.link(margin + 175, y - 5, 15, 10, { url: projCopyUrl });

  y += 8;

  doc.setFontSize(11);
  doc.setTextColor(TEXT_DARK);
  doc.setFont('helvetica', 'bold');
  doc.text(safeStr('LEGAL FUNDER:'), margin + 5, y);
  doc.setFont('helvetica', 'normal');
  doc.text(safeStr(String(app.funderName || app.funder_name || "N/A")), margin + 50, y);
  doc.setTextColor(LBG_PRIMARY);
  doc.setFontSize(8);
  const funderCopyUrl = `http://localhost:5174/?copy=${encodeURIComponent(app.funderName || app.funder_name || "")}`;
  doc.text(safeStr('(COPY)'), margin + 180, y);
  doc.link(margin + 175, y - 5, 15, 10, { url: funderCopyUrl });
  y += 15;

  // --- 2. INTEGRATED CHARITY DATA ---
  drawSectionHeader(doc, safeStr('2. INTEGRATED CHARITY DATA'), margin, y);
  y += 12;

  // Resilience: Check for dataJson directly (new schema) or common_data_id (old schema)
  let commonFields = [];
  if (Array.isArray(app.dataJson)) {
    commonFields = app.dataJson;
  } else if (app.common_data_id) {
    const template = (user.templates || mockTemplates).find(t => t.id === app.common_data_id);
    if (template) {
      const keys = JSON.parse(app.selected_common_keys || '[]');
      let fields = [];
      if (Array.isArray(template.dataJson)) fields = template.dataJson;
      else if (template.data_json) {
        try { fields = JSON.parse(template.data_json).commonFields || []; } catch (e) { fields = []; }
      }
      commonFields = fields.filter(f => keys.includes(f.id));
    }
  }

  if (commonFields.length > 0) {
    commonFields.forEach(f => {
      // Light background for key-value pair
      doc.setFillColor(250, 250, 250);
      doc.rect(margin + 2, y - 5, pageWidth - (margin * 2) - 4, 10, 'F');
      
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(LBG_PRIMARY);
      doc.setFontSize(10);
      doc.text(safeStr(`${f.key}:`), margin + 5, y + 1);
      
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(TEXT_DARK);
      const valText = doc.splitTextToSize(safeStr(String(f.value)), pageWidth - (margin * 2) - 70);
      doc.text(valText, margin + 65, y + 1);
      
      const fieldUrl = `http://localhost:5174/?copy=${encodeURIComponent(f.value || "")}`;
      doc.setTextColor(LBG_PRIMARY);
      doc.setFontSize(7);
      doc.text(safeStr('(COPY)'), margin + pageWidth - 35, y + 1);
      doc.link(margin + pageWidth - 40, y - 5, 20, 10, { url: fieldUrl });

      y += (valText.length * 6) + 4;
      if (y > 270) { doc.addPage(); y = 20; }
    });
    y += 10;
  }

  // --- 3. APPLICATION SPECIFIC DETAILS ---
  drawSectionHeader(doc, safeStr('3. APPLICATION SPECIFIC DETAILS'), margin, y);
  y += 12;

  let appSpecific = [];
  if (Array.isArray(app.applicationDataJson)) {
    appSpecific = app.applicationDataJson;
  } else if (app.application_number) {
     // fallback for reports fetch...
     appSpecific = app.applicationDataJson || [];
  } else if (app.application_data_json) {
    try {
      const parsed = JSON.parse(app.application_data_json);
      appSpecific = parsed.applicationFields || [];
    } catch(e) { appSpecific = []; }
  }

  appSpecific.forEach(f => {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(LBG_PRIMARY);
    doc.text(safeStr(String(f.key || "Key").toUpperCase()), margin + 5, y);
    y += 7;

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(TEXT_DARK);
    const splitText = doc.splitTextToSize(safeStr(String(f.value || "")), pageWidth - (margin * 2) - 10);
    doc.text(splitText, margin + 5, y);
    
    // Add Copy Link for App Specific
    const appFieldUrl = `http://localhost:5174/?copy=${encodeURIComponent(f.value || "")}`;
    doc.setTextColor(LBG_PRIMARY);
    doc.setFontSize(7);
    doc.text(safeStr('[COPY]'), margin + pageWidth - 45, y - 8);
    doc.link(margin + pageWidth - 50, y - 12, 30, 10, { url: appFieldUrl });

    y += (splitText.length * 6) + 10;
    
    // Separator line
    doc.setDrawColor(230);
    doc.line(margin + 5, y - 5, pageWidth - margin - 5, y - 5);
    
    if (y > 260) { doc.addPage(); y = 20; }
  });

  // --- OUTCOME SECTION ---
  if (app.outcome_comments) {
    y += 10;
    doc.setFillColor(LBG_LIGHT_GREEN);
    doc.rect(margin + 2, y, pageWidth - (margin * 2) - 4, 30, 'F');
    y += 10;
    doc.setFontSize(12); doc.setFont('helvetica', 'bold'); doc.setTextColor(LBG_PRIMARY);
    doc.text('OUTCOME COMMENTS:', margin + 10, y);
    y += 7;
    doc.setFontSize(11); doc.setFont('helvetica', 'italic'); doc.setTextColor(TEXT_DARK);
    doc.text(app.outcome_comments, margin + 10, y);
  }

  // Footer Logic
  const pageCount = doc.internal.getNumberOfPages();
  const charityDisplay = (user?.charityName || `CHARITY #${user?.charityId || 'N/A'}`).toUpperCase();
  const appRef = (app.applicationNumber || app.application_number || 'UNKNOWN_REF').toUpperCase();

  for(let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      
      // Bottom Bar
      doc.setFillColor(LBG_PRIMARY);
      doc.rect(0, 287, pageWidth, 10, 'F');
      
      doc.setFontSize(8);
      doc.setTextColor(255, 255, 255);
      doc.text(safeStr(`CONFIDENTIAL  |  ${charityDisplay}  |  Page ${i} of ${pageCount}`), pageWidth / 2, 293, { align: 'center' });
  }

  doc.save(safeStr(`${appRef}_Official_Report.pdf`));
    console.log('[PDF Export] PDF Generated Successfully.');
  } catch (err) {
    console.error('[PDF Export] Failed to generate PDF:', err);
    alert('Critical Rendering Error: The PDF document could not be generated. Please ensure all data fields contain valid characters.');
  }
};

// Helper for Section Headers
const drawSectionHeader = (doc, title, margin, y) => {
    // Underline and accent
    doc.setFillColor(LBG_PRIMARY);
    doc.rect(margin, y - 1, 5, 5, 'F'); // Little box accent
    
    doc.setFontSize(15);
    doc.setTextColor(LBG_PRIMARY);
    doc.setFont('helvetica', 'bold');
    doc.text(safeStr(title), margin + 8, y + 3);
    
    doc.setDrawColor(LBG_PRIMARY);
    doc.setLineWidth(0.5);
    doc.line(margin, y + 6, doc.internal.pageSize.width - margin, y + 6);
};
